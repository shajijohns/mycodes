// ================================================================
// UserDetailPage.tsx — User detail view + edit form + save
// ================================================================
import React, { useState, useEffect, useCallback } from 'react';
import type { IAzureUser, IFormField, IUpdateUserRequest, UpdateStatus, INotification } from '../interfaces/IAzureUser';
import { useAppContext } from '../context/AppContext';
import { useAzureUser } from '../hooks/useAzureUser';
import { BASIC_PROFILE_FIELDS, CONTACT_PROFILE_FIELDS } from '../utils/formFields';
import { NotificationStack } from '../components/NotificationStack';

// ── Array field editor ────────────────────────────────────────
const ArrayFieldEditor: React.FC<{
  label: string; values: string[]; placeholder: string;
  onChange: (v: string[]) => void;
}> = ({ label, values, placeholder, onChange }) => {
  const [inputVal, setInputVal] = useState('');
  const add = () => {
    const t = inputVal.trim();
    if (t && !values.includes(t)) { onChange([...values, t]); setInputVal(''); }
  };
  return (
    <div>
      <label style={labelSt}>{label}</label>
      <div style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
        <input value={inputVal} onChange={e => setInputVal(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), add())}
          placeholder={placeholder} style={{ ...inputSt, flex: 1 }} />
        <button onClick={add} style={addBtnSt}>+ Add</button>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {values.map((v, i) => (
          <span key={i} style={tagSt}>
            {v}
            <button onClick={() => onChange(values.filter((_, j) => j !== i))} style={tagXSt}>×</button>
          </span>
        ))}
      </div>
    </div>
  );
};

// ── Section card ──────────────────────────────────────────────
const SectionCard: React.FC<{
  title: string; icon: string; accent: string; children: React.ReactNode;
}> = ({ title, icon, accent, children }) => (
  <div style={{
    background: '#0f172a', borderRadius: 12, padding: 28,
    border: '1px solid #1e293b', boxShadow: '0 2px 16px rgba(0,0,0,0.3)',
    position: 'relative', overflow: 'hidden',
  }}>
    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3,
      background: `linear-gradient(90deg,${accent},transparent)` }} />
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 24 }}>
      <span style={{ fontSize: 20 }}>{icon}</span>
      <h3 style={{ margin: 0, color: accent, fontSize: 14, fontWeight: 700,
        textTransform: 'uppercase', letterSpacing: '1px' }}>{title}</h3>
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
      {children}
    </div>
  </div>
);

// ── Save button with status ───────────────────────────────────
const SaveButton: React.FC<{ status: UpdateStatus; onClick: () => void; hasChanges: boolean }> = ({
  status, onClick, hasChanges,
}) => {
  const cfg = {
    idle:    { label: '💾 Save Changes to Azure AD',   bg: 'linear-gradient(135deg,#0ea5e9,#6366f1)', sh: '0 4px 24px rgba(99,102,241,0.4)' },
    loading: { label: '⟳ Updating Azure AD...',        bg: '#334155', sh: 'none' },
    success: { label: '✓ Saved Successfully!',         bg: 'linear-gradient(135deg,#22c55e,#16a34a)', sh: '0 4px 24px rgba(34,197,94,0.4)' },
    error:   { label: '✕ Failed — Click to Retry',     bg: 'linear-gradient(135deg,#ef4444,#dc2626)', sh: '0 4px 24px rgba(239,68,68,0.4)' },
  };
  const { label, bg, sh } = cfg[status];
  return (
    <button onClick={onClick} disabled={status === 'loading' || !hasChanges} style={{
      padding: '13px 32px', fontSize: 14, fontWeight: 700, border: 'none', borderRadius: 10,
      cursor: status === 'loading' || !hasChanges ? 'not-allowed' : 'pointer',
      background: !hasChanges ? '#1e293b' : bg,
      color: !hasChanges ? '#475569' : '#fff',
      boxShadow: hasChanges ? sh : 'none',
      transition: 'all 0.3s', letterSpacing: '0.3px',
    }}>{label}</button>
  );
};

// ── Read-only info row ────────────────────────────────────────
const InfoRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
    <span style={{ ...labelSt }}>{label}</span>
    <span style={{ color: '#94a3b8', fontSize: 13, fontFamily: 'monospace',
      background: '#0a1628', padding: '8px 12px', borderRadius: 6,
      border: '1px solid #1e293b' }}>{value || '—'}</span>
  </div>
);

// ── Main Page ─────────────────────────────────────────────────
export const UserDetailPage: React.FC = () => {
  const { selectedUser, navigateToSearch } = useAppContext();
  const { status, notifications, updateUser, clearNotification } = useAzureUser();
  const [formData, setFormData] = useState<Partial<IAzureUser>>({});
  const [hasChanges, setHasChanges] = useState(false);
  const [activeTab, setActiveTab] = useState<'basic' | 'contact'>('basic');

  // Populate form from selectedUser
  useEffect(() => {
    if (selectedUser) {
      setFormData({
        givenName: selectedUser.givenName,
        surname: selectedUser.surname,
        displayName: selectedUser.displayName,
        jobTitle: selectedUser.jobTitle,
        department: selectedUser.department,
        companyName: selectedUser.companyName,
        officeLocation: selectedUser.officeLocation,
        preferredLanguage: selectedUser.preferredLanguage,
        mobilePhone: selectedUser.mobilePhone,
        businessPhones: [...(selectedUser.businessPhones || [])],
        otherMails: [...(selectedUser.otherMails || [])],
        mailNickname: selectedUser.mailNickname,
      });
      setHasChanges(false);
    }
  }, [selectedUser]);

  const handleFieldChange = useCallback((key: keyof IAzureUser, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  }, []);

  const handleSave = useCallback(async () => {
    if (!selectedUser) return;
    const payload: IUpdateUserRequest = {
      basicProfile: {
        givenName: formData.givenName,
        surname: formData.surname,
        displayName: formData.displayName,
        jobTitle: formData.jobTitle,
        department: formData.department,
        companyName: formData.companyName,
        officeLocation: formData.officeLocation,
        preferredLanguage: formData.preferredLanguage,
      },
      contactProfile: {
        mobilePhone: formData.mobilePhone,
        businessPhones: formData.businessPhones as string[],
        otherMails: formData.otherMails as string[],
        mailNickname: formData.mailNickname,
      },
    };
    await updateUser(selectedUser.id, payload);
    setHasChanges(false);
  }, [formData, selectedUser, updateUser]);

  const renderField = (field: IFormField) => {
    const val = formData[field.key];
    if (field.type === 'array') {
      return (
        <div key={field.key} style={{ gridColumn: 'span 2' }}>
          <ArrayFieldEditor
            label={field.label}
            values={(val as string[]) || []}
            placeholder={field.placeholder}
            onChange={v => handleFieldChange(field.key, v)}
          />
        </div>
      );
    }
    if (field.type === 'select') {
      return (
        <div key={field.key}>
          <label style={labelSt}>{field.label}{field.required && <span style={{ color: '#ef4444' }}> *</span>}</label>
          <select value={(val as string) || ''} onChange={e => handleFieldChange(field.key, e.target.value)}
            style={{ ...inputSt, cursor: 'pointer' }}>
            <option value="">Select...</option>
            {field.options?.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        </div>
      );
    }
    return (
      <div key={field.key}>
        <label style={labelSt}>
          {field.label}{field.required && <span style={{ color: '#ef4444' }}> *</span>}
        </label>
        <input type={field.type} value={(val as string) || ''}
          onChange={e => handleFieldChange(field.key, e.target.value)}
          placeholder={field.placeholder} style={inputSt} />
      </div>
    );
  };

  if (!selectedUser) {
    return (
      <div style={{ padding: 60, textAlign: 'center', color: '#64748b' }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
        <p>No user selected. <button onClick={navigateToSearch} style={linkBtnSt}>Go to Search</button></p>
      </div>
    );
  }

  return (
    <div style={{ padding: '32px 40px', maxWidth: 980, margin: '0 auto' }}>
      <style>{`
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .edit-input:focus { outline: none; border-color: #6366f1 !important; box-shadow: 0 0 0 3px rgba(99,102,241,0.2); }
        input::placeholder { color: #334155; }
      `}</style>

      <NotificationStack notifications={notifications} onDismiss={clearNotification} />

      {/* ── Back + Breadcrumb ── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
        <button onClick={navigateToSearch} style={{
          padding: '7px 14px', borderRadius: 7, border: '1px solid #334155',
          background: 'transparent', color: '#94a3b8', cursor: 'pointer', fontSize: 13,
          display: 'flex', alignItems: 'center', gap: 6,
        }}>← Back to Search</button>
        <span style={{ color: '#334155' }}>/</span>
        <span style={{ color: '#64748b', fontSize: 13 }}>User Directory</span>
        <span style={{ color: '#334155' }}>/</span>
        <span style={{ color: '#94a3b8', fontSize: 13 }}>{selectedUser.displayName}</span>
      </div>

      {/* ── User identity card ── */}
      <div style={{
        background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12,
        padding: '24px 28px', marginBottom: 28, display: 'flex', gap: 20, alignItems: 'center',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, height: 3,
          background: 'linear-gradient(90deg,#6366f1,#0ea5e9,transparent)',
        }} />
        {/* Avatar */}
        <div style={{
          width: 64, height: 64, borderRadius: '50%', flexShrink: 0,
          background: 'linear-gradient(135deg,#6366f1,#0ea5e9)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontWeight: 800, fontSize: 22,
        }}>
          {((selectedUser.givenName?.[0] ?? '') + (selectedUser.surname?.[0] ?? '')).toUpperCase() || '?'}
        </div>
        <div style={{ flex: 1 }}>
          <h2 style={{ margin: '0 0 4px', fontSize: 22, fontWeight: 800, color: '#f1f5f9' }}>
            {selectedUser.displayName}
          </h2>
          <p style={{ margin: 0, color: '#6366f1', fontSize: 13, fontFamily: 'monospace' }}>
            {selectedUser.userPrincipalName}
          </p>
          <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 13 }}>
            {selectedUser.jobTitle && `${selectedUser.jobTitle} · `}
            {selectedUser.department}
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 24px', fontSize: 12 }}>
          <InfoRow label="Object ID" value={selectedUser.id} />
          <InfoRow label="Mail" value={selectedUser.mail || ''} />
        </div>
      </div>

      {/* ── Tabs ── */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1px solid #1e293b', paddingBottom: 0 }}>
        {(['basic', 'contact'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} style={{
            padding: '10px 22px', border: 'none', borderRadius: '8px 8px 0 0', cursor: 'pointer',
            fontWeight: 700, fontSize: 13, letterSpacing: '0.3px',
            background: activeTab === tab ? '#0f172a' : 'transparent',
            color: activeTab === tab ? '#6366f1' : '#64748b',
            borderBottom: activeTab === tab ? '2px solid #6366f1' : '2px solid transparent',
            transition: 'all 0.15s',
          }}>
            {tab === 'basic' ? '👤 Basic Profile' : '📞 Contact Info'}
          </button>
        ))}
        {hasChanges && (
          <span style={{
            marginLeft: 'auto', alignSelf: 'center',
            padding: '4px 12px', borderRadius: 20, background: '#f59e0b20',
            color: '#f59e0b', fontSize: 12, fontWeight: 600,
          }}>● Unsaved changes</span>
        )}
      </div>

      {/* ── Form sections ── */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        {activeTab === 'basic' && (
          <SectionCard title="Basic Profile" icon="👤" accent="#6366f1">
            {BASIC_PROFILE_FIELDS.map(renderField)}
          </SectionCard>
        )}
        {activeTab === 'contact' && (
          <SectionCard title="Contact Information" icon="📞" accent="#0ea5e9">
            {CONTACT_PROFILE_FIELDS.map(renderField)}
          </SectionCard>
        )}

        {/* ── Action bar ── */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '18px 24px', background: '#0f172a', borderRadius: 12,
          border: '1px solid #1e293b',
        }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={navigateToSearch} style={{
              padding: '11px 20px', borderRadius: 8, border: '1px solid #334155',
              background: 'transparent', color: '#94a3b8', cursor: 'pointer', fontSize: 13,
            }}>← Back</button>
            <button
              onClick={() => { if (selectedUser) { setFormData({ ...selectedUser }); setHasChanges(false); } }}
              style={{
                padding: '11px 20px', borderRadius: 8, border: '1px solid #334155',
                background: 'transparent', color: '#94a3b8', cursor: 'pointer', fontSize: 13,
              }}>↺ Reset</button>
          </div>
          <SaveButton status={status} onClick={handleSave} hasChanges={hasChanges} />
        </div>
      </div>
    </div>
  );
};

// ── Styles ────────────────────────────────────────────────────
const labelSt: React.CSSProperties = {
  display: 'block', marginBottom: 6, fontSize: 11, fontWeight: 700,
  color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.6px',
};
const inputSt: React.CSSProperties = {
  width: '100%', padding: '10px 14px', borderRadius: 8, fontSize: 14,
  background: '#0a1628', border: '1px solid #1e293b', color: '#e2e8f0',
  transition: 'border-color 0.2s, box-shadow 0.2s', boxSizing: 'border-box',
};
const addBtnSt: React.CSSProperties = {
  padding: '10px 14px', background: '#1e293b', border: '1px solid #334155',
  borderRadius: 8, color: '#94a3b8', cursor: 'pointer', fontSize: 13, fontWeight: 600,
};
const tagSt: React.CSSProperties = {
  display: 'inline-flex', alignItems: 'center', gap: 6,
  padding: '4px 10px', background: '#1e293b', borderRadius: 20,
  color: '#94a3b8', fontSize: 13,
};
const tagXSt: React.CSSProperties = {
  background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 16, padding: 0,
};
const linkBtnSt: React.CSSProperties = {
  background: 'none', border: 'none', color: '#6366f1', cursor: 'pointer', fontSize: 14, textDecoration: 'underline',
};

export default UserDetailPage;
