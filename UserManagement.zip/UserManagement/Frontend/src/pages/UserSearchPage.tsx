// ================================================================
// UserSearchPage.tsx — Search bar + Results grid
// ================================================================
import React, { useCallback } from 'react';
import type { IAzureUser } from '../interfaces/IAzureUser';
import { useUserSearch } from '../hooks/useUserSearch';
import { useAppContext } from '../context/AppContext';
import { NotificationStack } from '../components/NotificationStack';

// ── Column definitions for the results grid ──────────────────
const GRID_COLUMNS: { key: keyof IAzureUser; label: string; width: string }[] = [
  { key: 'displayName',       label: 'Display Name',   width: '18%' },
  { key: 'givenName',         label: 'First Name',     width: '12%' },
  { key: 'surname',           label: 'Last Name',      width: '12%' },
  { key: 'mail',              label: 'Email',          width: '20%' },
  { key: 'jobTitle',          label: 'Job Title',      width: '14%' },
  { key: 'department',        label: 'Department',     width: '12%' },
  { key: 'officeLocation',    label: 'Office',         width: '8%'  },
];

const SEARCH_BY_OPTIONS = [
  { value: 'displayName',      label: 'Display Name'    },
  { value: 'mail',             label: 'Email'           },
  { value: 'userPrincipalName',label: 'UPN'             },
  { value: 'department',       label: 'Department'      },
  { value: 'jobTitle',         label: 'Job Title'       },
] as const;

// ── Avatar initials ───────────────────────────────────────────
const Avatar: React.FC<{ user: IAzureUser }> = ({ user }) => {
  const initials = ((user.givenName?.[0] ?? '') + (user.surname?.[0] ?? '')).toUpperCase() || '?';
  const colors = ['#6366f1','#0ea5e9','#22c55e','#f59e0b','#ec4899','#14b8a6'];
  const color = colors[initials.charCodeAt(0) % colors.length];
  return (
    <div style={{
      width: 32, height: 32, borderRadius: '50%', background: color,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#fff', fontWeight: 700, fontSize: 12, flexShrink: 0,
    }}>{initials}</div>
  );
};

// ── Sort indicator ────────────────────────────────────────────
const SortIcon: React.FC<{ active: boolean; direction: 'asc' | 'desc' }> = ({ active, direction }) => (
  <span style={{ marginLeft: 4, opacity: active ? 1 : 0.3, fontSize: 11 }}>
    {active ? (direction === 'asc' ? '▲' : '▼') : '⇅'}
  </span>
);

// ── Main page ─────────────────────────────────────────────────
export const UserSearchPage: React.FC = () => {
  const {
    query, setQuery, executeSearch, isLoading, hasSearched,
    sortedResults, totalCount, sortState, handleSort,
    notifications, clearNotification, clearResults,
  } = useUserSearch();

  const { navigateToDetail } = useAppContext();

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') executeSearch();
  }, [executeSearch]);

  const handleRowClick = useCallback((user: IAzureUser) => {
    navigateToDetail(user);
  }, [navigateToDetail]);

  return (
    <div style={{ padding: '32px 40px', maxWidth: 1300, margin: '0 auto' }}>
      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes shimmer { 0%{background-position:-400px 0} 100%{background-position:400px 0} }
        .grid-row:hover { background: #1e293b !important; cursor: pointer; }
        .grid-row:hover .row-action { opacity: 1 !important; }
        .search-input:focus { outline: none; border-color: #6366f1 !important; box-shadow: 0 0 0 3px rgba(99,102,241,0.2); }
        select:focus { outline: none; border-color: #6366f1; }
        .sort-th:hover { background: #1e293b !important; cursor: pointer; }
      `}</style>

      <NotificationStack notifications={notifications} onDismiss={clearNotification} />

      {/* ── Page Header ── */}
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, color: '#f1f5f9' }}>
          🔍 User Directory
        </h1>
        <p style={{ margin: '6px 0 0', color: '#64748b', fontSize: 14 }}>
          Search and manage Azure Active Directory users via Microsoft Graph API
        </p>
      </div>

      {/* ── Search Bar ── */}
      <div style={{
        background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12,
        padding: '24px 28px', marginBottom: 28,
      }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' }}>
          {/* Search By dropdown */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={labelSt}>Search By</label>
            <select
              value={query.searchBy}
              onChange={e => setQuery({ searchBy: e.target.value as typeof query.searchBy })}
              style={{
                padding: '10px 14px', borderRadius: 8, background: '#0a1628',
                border: '1px solid #1e293b', color: '#94a3b8', fontSize: 14, cursor: 'pointer',
              }}
            >
              {SEARCH_BY_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>

          {/* Search term input */}
          <div style={{ flex: 1, minWidth: 240, display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={labelSt}>Search Term</label>
            <input
              className="search-input"
              type="text"
              value={query.searchTerm}
              onChange={e => setQuery({ searchTerm: e.target.value })}
              onKeyDown={handleKeyDown}
              placeholder={`Search by ${SEARCH_BY_OPTIONS.find(o => o.value === query.searchBy)?.label}...`}
              style={{
                padding: '10px 14px', borderRadius: 8, background: '#0a1628',
                border: '1px solid #1e293b', color: '#e2e8f0', fontSize: 14,
                transition: 'border-color 0.2s, box-shadow 0.2s',
              }}
            />
          </div>

          {/* Page size */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={labelSt}>Results</label>
            <select
              value={query.pageSize}
              onChange={e => setQuery({ pageSize: Number(e.target.value) })}
              style={{
                padding: '10px 14px', borderRadius: 8, background: '#0a1628',
                border: '1px solid #1e293b', color: '#94a3b8', fontSize: 14, cursor: 'pointer',
              }}
            >
              {[10, 20, 50, 100].map(n => <option key={n} value={n}>{n} per page</option>)}
            </select>
          </div>

          {/* Search button */}
          <button
            onClick={() => executeSearch()}
            disabled={isLoading}
            style={{
              padding: '10px 28px', borderRadius: 8, border: 'none', fontWeight: 700,
              fontSize: 14, cursor: isLoading ? 'not-allowed' : 'pointer',
              background: isLoading ? '#1e293b' : 'linear-gradient(135deg,#6366f1,#0ea5e9)',
              color: isLoading ? '#475569' : '#fff',
              transition: 'all 0.2s', letterSpacing: '0.3px',
              display: 'flex', alignItems: 'center', gap: 8,
            }}
          >
            {isLoading ? (
              <><span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>⟳</span> Searching...</>
            ) : '🔍 Search'}
          </button>

          {hasSearched && (
            <button
              onClick={clearResults}
              style={{
                padding: '10px 16px', borderRadius: 8, border: '1px solid #334155',
                background: 'transparent', color: '#94a3b8', fontSize: 13, cursor: 'pointer',
              }}
            >✕ Clear</button>
          )}
        </div>
      </div>

      {/* ── Results Grid ── */}
      {hasSearched && (
        <div style={{ animation: 'fadeIn 0.3s ease' }}>
          {/* Result count bar */}
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            marginBottom: 12, padding: '0 4px',
          }}>
            <span style={{ color: '#64748b', fontSize: 13 }}>
              {isLoading ? 'Searching...' : `${totalCount} result${totalCount !== 1 ? 's' : ''} found`}
            </span>
            <span style={{ color: '#475569', fontSize: 12 }}>
              Click a row to edit
            </span>
          </div>

          {/* Table */}
          <div style={{
            background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12,
            overflow: 'hidden', boxShadow: '0 4px 24px rgba(0,0,0,0.3)',
          }}>
            {/* Header */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: `40px ${GRID_COLUMNS.map(c => c.width).join(' ')} 80px`,
              background: '#0a1628', borderBottom: '1px solid #1e293b',
              padding: '0 16px',
            }}>
              <div style={{ padding: '12px 0' }} />
              {GRID_COLUMNS.map(col => (
                <div
                  key={col.key}
                  className="sort-th"
                  onClick={() => handleSort(col.key)}
                  style={{
                    padding: '12px 8px', fontSize: 11, fontWeight: 700,
                    color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.8px',
                    display: 'flex', alignItems: 'center', userSelect: 'none',
                    borderRadius: 4, transition: 'background 0.15s',
                  }}
                >
                  {col.label}
                  <SortIcon
                    active={sortState.column === col.key}
                    direction={sortState.column === col.key ? sortState.direction : 'asc'}
                  />
                </div>
              ))}
              <div style={{ padding: '12px 8px', fontSize: 11, fontWeight: 700, color: '#64748b',
                textTransform: 'uppercase', letterSpacing: '0.8px' }}>
                Action
              </div>
            </div>

            {/* Rows */}
            {isLoading ? (
              /* Skeleton rows */
              Array.from({ length: 5 }).map((_, i) => (
                <div key={i} style={{
                  display: 'grid',
                  gridTemplateColumns: `40px ${GRID_COLUMNS.map(c => c.width).join(' ')} 80px`,
                  padding: '0 16px', borderBottom: '1px solid #0f172a',
                  background: i % 2 === 0 ? '#0f172a' : '#0a1628',
                }}>
                  {Array.from({ length: GRID_COLUMNS.length + 2 }).map((_, j) => (
                    <div key={j} style={{ padding: '14px 8px' }}>
                      <div style={{
                        height: 12, borderRadius: 4,
                        background: 'linear-gradient(90deg,#1e293b 25%,#0f172a 50%,#1e293b 75%)',
                        backgroundSize: '400px 100%',
                        animation: 'shimmer 1.5s infinite',
                        width: j === 0 ? 32 : '80%',
                      }} />
                    </div>
                  ))}
                </div>
              ))
            ) : sortedResults.length === 0 ? (
              <div style={{
                padding: '60px 20px', textAlign: 'center',
                color: '#475569', fontSize: 14,
              }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>👥</div>
                <div>No users found. Try a different search term.</div>
              </div>
            ) : (
              sortedResults.map((user, idx) => (
                <div
                  key={user.id}
                  className="grid-row"
                  onClick={() => handleRowClick(user)}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: `40px ${GRID_COLUMNS.map(c => c.width).join(' ')} 80px`,
                    padding: '0 16px',
                    background: idx % 2 === 0 ? '#0f172a' : '#0a1628',
                    borderBottom: '1px solid #1a2540',
                    transition: 'background 0.15s',
                    alignItems: 'center',
                  }}
                >
                  {/* Avatar */}
                  <div style={{ padding: '10px 0' }}>
                    <Avatar user={user} />
                  </div>

                  {/* Data cells */}
                  {GRID_COLUMNS.map(col => (
                    <div key={col.key} style={{
                      padding: '12px 8px', fontSize: 13,
                      color: col.key === 'displayName' ? '#e2e8f0' : '#94a3b8',
                      fontWeight: col.key === 'displayName' ? 600 : 400,
                      overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                    }}>
                      {col.key === 'mail' ? (
                        <span style={{ color: '#6366f1', fontSize: 12 }}>
                          {String(user[col.key] ?? '—')}
                        </span>
                      ) : (
                        String(user[col.key] ?? '—')
                      )}
                    </div>
                  ))}

                  {/* Edit button */}
                  <div style={{ padding: '10px 8px' }}>
                    <button
                      className="row-action"
                      onClick={e => { e.stopPropagation(); handleRowClick(user); }}
                      style={{
                        padding: '5px 12px', borderRadius: 6, border: '1px solid #334155',
                        background: '#1e293b', color: '#6366f1', fontSize: 12,
                        cursor: 'pointer', fontWeight: 600, opacity: 0.7,
                        transition: 'opacity 0.15s',
                      }}
                    >✏ Edit</button>
                  </div>
                </div>
              ))
            )}

            {/* Footer */}
            {!isLoading && sortedResults.length > 0 && (
              <div style={{
                padding: '12px 24px', background: '#0a1628', borderTop: '1px solid #1e293b',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <span style={{ color: '#475569', fontSize: 12 }}>
                  Showing {sortedResults.length} of {totalCount} users
                </span>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    disabled={query.pageNumber <= 1}
                    onClick={() => { setQuery({ pageNumber: query.pageNumber - 1 }); executeSearch({ pageNumber: query.pageNumber - 1 }); }}
                    style={{
                      padding: '5px 14px', borderRadius: 6, border: '1px solid #334155',
                      background: 'transparent', color: query.pageNumber <= 1 ? '#334155' : '#94a3b8',
                      cursor: query.pageNumber <= 1 ? 'not-allowed' : 'pointer', fontSize: 13,
                    }}
                  >← Prev</button>
                  <span style={{ padding: '5px 10px', color: '#64748b', fontSize: 13 }}>
                    Page {query.pageNumber}
                  </span>
                  <button
                    disabled={sortedResults.length < query.pageSize}
                    onClick={() => { setQuery({ pageNumber: query.pageNumber + 1 }); executeSearch({ pageNumber: query.pageNumber + 1 }); }}
                    style={{
                      padding: '5px 14px', borderRadius: 6, border: '1px solid #334155',
                      background: 'transparent',
                      color: sortedResults.length < query.pageSize ? '#334155' : '#94a3b8',
                      cursor: sortedResults.length < query.pageSize ? 'not-allowed' : 'pointer', fontSize: 13,
                    }}
                  >Next →</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// ── Shared mini styles ────────────────────────────────────────
const labelSt: React.CSSProperties = {
  fontSize: 11, fontWeight: 700, color: '#64748b',
  textTransform: 'uppercase', letterSpacing: '0.6px',
};

export default UserSearchPage;
