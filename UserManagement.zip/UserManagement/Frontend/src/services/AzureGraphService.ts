// ================================================================
// AzureGraphService.ts — Frontend API Service (OOP / Singleton)
// ================================================================

import type {
    IAzureUser,
    IUpdateUserRequest,
    IApiResponse,
    IUserSearchQuery,
    IUserSearchResult,
} from '../interfaces/IAzureUser';

// ── Abstract base ─────────────────────────────────────────────
abstract class BaseApiService {
    protected readonly baseUrl: string;

    constructor(baseUrl: string) {
        this.baseUrl = baseUrl;
    }

    protected async request<T>(
        endpoint: string,
        options: RequestInit = {}
    ): Promise<IApiResponse<T>> {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    ...options.headers,
                },
            });
            const json = await response.json();
            if (!response.ok) {
                return {
                    success: false,
                    message: json?.message ?? `HTTP ${response.status}: ${response.statusText}`,
                    errors: json?.errors ?? [],
                    statusCode: response.status,
                };
            }
            return {
                success: true,
                data: json?.data ?? json,
                message: json?.message ?? 'Success',
                statusCode: response.status,
            };
        } catch (err) {
            return {
                success: false,
                message: err instanceof Error ? err.message : 'Network error occurred',
                statusCode: 0,
            };
        }
    }
}

// ── Concrete Azure Graph service (Singleton) ──────────────────
export class AzureGraphService extends BaseApiService {
    private static _instance: AzureGraphService;

    private constructor() {
        super(import.meta.env.VITE_API_BASE_URL ?? 'https://localhost:59297/api');
    }

    static getInstance(): AzureGraphService {
        if (!AzureGraphService._instance) {
            AzureGraphService._instance = new AzureGraphService();
        }
        return AzureGraphService._instance;
    }

    // ── GET /api/users/{userId} ─────────────────────────────────
    getUser(userId: string): Promise<IApiResponse<IAzureUser>> {
        return this.request<IAzureUser>(`/users/${encodeURIComponent(userId)}`);
    }

    // ── GET /api/users/search?searchTerm=...&searchBy=...&pageSize=...&pageNumber=...
    searchUsers(query: IUserSearchQuery): Promise<IApiResponse<IUserSearchResult>> {
        const params = new URLSearchParams({
            searchTerm: query.searchTerm,
            searchBy: query.searchBy,
            pageSize: String(query.pageSize),
            pageNumber: String(query.pageNumber),
        });
        return this.request<IUserSearchResult>(`/users/search?${params.toString()}`);
    }

    // ── PATCH /api/users/{userId} ───────────────────────────────
    updateUser(userId: string, payload: IUpdateUserRequest): Promise<IApiResponse<IAzureUser>> {
        return this.request<IAzureUser>(`/users/${encodeURIComponent(userId)}`, {
            method: 'PATCH',
            body: JSON.stringify(payload),
        });
    }

    // ── PATCH /api/users/{userId}/basic-profile ─────────────────
    updateBasicProfile(userId: string, payload: Partial<IAzureUser>): Promise<IApiResponse<IAzureUser>> {
        return this.request<IAzureUser>(`/users/${encodeURIComponent(userId)}/basic-profile`, {
            method: 'PATCH',
            body: JSON.stringify(payload),
        });
    }

    // ── PATCH /api/users/{userId}/contact-profile ───────────────
    updateContactProfile(userId: string, payload: Partial<IAzureUser>): Promise<IApiResponse<IAzureUser>> {
        return this.request<IAzureUser>(`/users/${encodeURIComponent(userId)}/contact-profile`, {
            method: 'PATCH',
            body: JSON.stringify(payload),
        });
    }
}

export const azureGraphService = AzureGraphService.getInstance();
