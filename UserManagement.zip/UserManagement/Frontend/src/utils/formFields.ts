// formFields.ts - Form field configuration for dynamic rendering
import type { IFormField } from '../interfaces/IAzureUser';

export const BASIC_PROFILE_FIELDS: IFormField[] = [
  { key: 'givenName',        label: 'First Name',          type: 'text',   placeholder: 'John',             required: true,  section: 'basic' },
  { key: 'surname',          label: 'Last Name',           type: 'text',   placeholder: 'Smith',            required: true,  section: 'basic' },
  { key: 'displayName',      label: 'Display Name',        type: 'text',   placeholder: 'John Smith',       required: true,  section: 'basic' },
  { key: 'jobTitle',         label: 'Job Title',           type: 'text',   placeholder: 'Software Engineer',               section: 'basic' },
  { key: 'department',       label: 'Department',          type: 'text',   placeholder: 'Engineering',                     section: 'basic' },
  { key: 'companyName',      label: 'Company Name',        type: 'text',   placeholder: 'Contoso Ltd',                     section: 'basic' },
  { key: 'officeLocation',   label: 'Office Location',     type: 'text',   placeholder: 'Building A, Floor 3',             section: 'basic' },
  { key: 'preferredLanguage',label: 'Preferred Language',  type: 'select', placeholder: 'en-US',                           section: 'basic',
    options: ['en-US','en-GB','fr-FR','de-DE','es-ES','it-IT','pt-BR','ja-JP','zh-CN','ar-SA'] },
];

export const CONTACT_PROFILE_FIELDS: IFormField[] = [
  { key: 'mobilePhone',      label: 'Mobile Phone',        type: 'tel',    placeholder: '+1 555 000 0000',  section: 'contact' },
  { key: 'businessPhones',   label: 'Business Phones',     type: 'array',  placeholder: '+1 555 000 0001',  section: 'contact' },
  { key: 'otherMails',       label: 'Other Emails',        type: 'array',  placeholder: 'alias@company.com', section: 'contact' },
  { key: 'mailNickname',     label: 'Mail Nickname',       type: 'text',   placeholder: 'jsmith',           section: 'contact' },
];

export const ALL_FIELDS: IFormField[] = [...BASIC_PROFILE_FIELDS, ...CONTACT_PROFILE_FIELDS];
