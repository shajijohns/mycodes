// ================================================================
// IAzureUser.ts — Core Azure Graph User Interfaces & Types
// ================================================================

export interface IBasicProfile {
    givenName: string;
    surname: string;
    displayName: string;
    jobTitle: string;
    department: string;
    companyName: string;
    officeLocation: string;
    preferredLanguage: string;
}

export interface IContactProfile {
    mobilePhone: string;
    businessPhones: string[];
    otherMails: string[];
    mailNickname: string;
}

export interface IAzureUser extends IBasicProfile, IContactProfile {
    id: string;
    userPrincipalName: string;
    mail: string;
}

export interface IUpdateUserRequest {
    basicProfile?: Partial<IBasicProfile>;
    contactProfile?: Partial<IContactProfile>;
}

export interface IApiResponse<T = void> {
    success: boolean;
    data?: T;
    message: string;
    errors?: string[];
    statusCode: number;
}

// NEW: Search query payload
export interface IUserSearchQuery {
    searchTerm: string;
    searchBy: 'displayName' | 'mail' | 'userPrincipalName' | 'department' | 'jobTitle';
    pageSize: number;
    pageNumber: number;
}

// NEW: Paginated search result
export interface IUserSearchResult {
    users: IAzureUser[];
    totalCount: number;
    pageNumber: number;
    pageSize: number;
    hasNextPage: boolean;
}

// NEW: Sort state for grid
export interface ISortState {
    column: keyof IAzureUser | null;
    direction: 'asc' | 'desc';
}

// NEW: App view/page enum
export type AppView = 'search' | 'detail';

export type UpdateStatus = 'idle' | 'loading' | 'success' | 'error';

export interface INotification {
    id: string;
    type: 'success' | 'error' | 'warning' | 'info';
    message: string;
    timestamp: number;
}

export interface IFormField {
    key: keyof IAzureUser;
    label: string;
    type: 'text' | 'tel' | 'email' | 'array' | 'select';
    placeholder: string;
    required?: boolean;
    section: 'basic' | 'contact';
    options?: string[];
}
