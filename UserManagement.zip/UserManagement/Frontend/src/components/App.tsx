// ================================================================
// App.tsx — Root: AppProvider + NavBar + View router
// ================================================================
import React from 'react';
import { AppProvider, useAppContext } from '../context/AppContext';
import { UserSearchPage } from '../pages/UserSearchPage';
import { UserDetailPage } from '../pages/UserDetailPage';

// ── Top navigation bar ────────────────────────────────────────
const NavBar: React.FC = () => {
    const { currentView, navigateToSearch } = useAppContext();
    return (
        <nav style={{
            background: '#0a1628', borderBottom: '1px solid #1e293b',
            padding: '0 32px', height: 56,
            display: 'flex', alignItems: 'center', gap: 16,
            position: 'sticky', top: 0, zIndex: 100,
        }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                    width: 30, height: 30, borderRadius: 7,
                    background: 'linear-gradient(135deg,#6366f1,#0ea5e9)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 14, color: '#fff', fontWeight: 800,
                }}>☁</div>
                <span style={{ color: '#f1f5f9', fontWeight: 800, fontSize: 15 }}>
                    Azure Graph Editor
                </span>
            </div>

            <span style={{ color: '#1e293b', fontSize: 20 }}>|</span>

            <button
                onClick={navigateToSearch}
                style={{
                    background: 'none', border: 'none', cursor: 'pointer', fontSize: 13,
                    color: currentView === 'search' ? '#6366f1' : '#64748b',
                    fontWeight: currentView === 'search' ? 700 : 400,
                    padding: '4px 8px', borderRadius: 4,
                }}
            >🔍 User Directory</button>

            {currentView === 'detail' && (
                <>
                    <span style={{ color: '#334155' }}>›</span>
                    <span style={{ color: '#94a3b8', fontSize: 13 }}>Edit User</span>
                </>
            )}

            <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{
                    padding: '3px 10px', borderRadius: 20, fontSize: 11,
                    background: '#22c55e20', color: '#22c55e', fontWeight: 600,
                }}>● API Connected</span>
                <a
                    href="https://localhost:59297/swagger"
                    target="_blank"
                    rel="noreferrer"
                    style={{
                        padding: '5px 12px', borderRadius: 6, border: '1px solid #334155',
                        background: 'transparent', color: '#64748b', fontSize: 12,
                        textDecoration: 'none',
                    }}
                >Swagger ↗</a>
            </div>
        </nav>
    );
};

// ── View router ───────────────────────────────────────────────
const AppRouter: React.FC = () => {
    const { currentView } = useAppContext();
    return currentView === 'search' ? <UserSearchPage /> : <UserDetailPage />;
};

// ── Root ──────────────────────────────────────────────────────
const App: React.FC = () => (
    <AppProvider>
        <div style={{ minHeight: '100vh', background: '#020617', fontFamily: "'Inter','Segoe UI',sans-serif" }}>
            <style>{`
                * { box-sizing: border-box; }
                body { margin: 0; padding: 0; }
                @keyframes slideIn  { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
                @keyframes spin     { from { transform: rotate(0deg);   } to { transform: rotate(360deg); } }
                @keyframes fadeIn   { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
                @keyframes shimmer  { 0% { background-position: -400px 0; } 100% { background-position: 400px 0; } }
                select option       { background: #0f172a; color: #e2e8f0; }
                ::-webkit-scrollbar { width: 6px; height: 6px; }
                ::-webkit-scrollbar-track { background: #0a1628; }
                ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
                input:focus, select:focus  { outline: none; border-color: #6366f1 !important; box-shadow: 0 0 0 3px rgba(99,102,241,0.2); }
                input::placeholder { color: #334155; }
            `}</style>
            <NavBar />
            <AppRouter />
        </div>
    </AppProvider>
);

export default App;
