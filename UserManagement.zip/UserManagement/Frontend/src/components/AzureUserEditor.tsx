// AzureUserEditor.tsx - Main Azure AD User Profile Editor Component
import React, { useState, useEffect, useCallback } from 'react';
import type { IAzureUser, IFormField, IUpdateUserRequest, UpdateStatus, INotification } from '../interfaces/IAzureUser';
import { useAzureUser } from '../hooks/useAzureUser';
import { BASIC_PROFILE_FIELDS, CONTACT_PROFILE_FIELDS } from '../utils/formFields';

// ── Sub-component: Notification Toast ──────────────────────
interface NotificationToastProps {
  notification: INotification;
  onDismiss: (id: string) => void;
}

const NotificationToast: React.FC<NotificationToastProps> = ({ notification, onDismiss }) => {
  const colorMap: Record<INotification['type'], string> = {
    success: '#22c55e',
    error:   '#ef4444',
    warning: '#f59e0b',
    info:    '#3b82f6',
  };
  const iconMap: Record<INotification['type'], string> = {
    success: '✓', error: '✕', warning: '⚠', info: 'ℹ',
  };
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '10px',
      padding: '12px 16px', borderRadius: '8px', marginBottom: '8px',
      background: '#1e293b', borderLeft: `4px solid ${colorMap[notification.type]}`,
      boxShadow: '0 4px 20px rgba(0,0,0,0.4)', animation: 'slideIn 0.3s ease',
    }}>
      <span style={{ color: colorMap[notification.type], fontWeight: 700, fontSize: '16px' }}>
        {iconMap[notification.type]}
      </span>
      <span style={{ color: '#e2e8f0', flex: 1, fontSize: '14px' }}>{notification.message}</span>
      <button
        onClick={() => onDismiss(notification.id)}
        style={{ background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', fontSize: '18px' }}
      >×</button>
    </div>
  );
};

// ── Sub-component: Array field editor (businessPhones / otherMails) ──
interface ArrayFieldProps {
  label: string;
  values: string[];
  placeholder: string;
  onChange: (values: string[]) => void;
}

const ArrayFieldEditor: React.FC<ArrayFieldProps> = ({ label, values, placeholder, onChange }) => {
  const [inputVal, setInputVal] = useState('');

  const addItem = () => {
    const trimmed = inputVal.trim();
    if (trimmed && !values.includes(trimmed)) {
      onChange([...values, trimmed]);
      setInputVal('');
    }
  };

  const removeItem = (idx: number) => {
    onChange(values.filter((_, i) => i !== idx));
  };

  return (
    <div>
      <label style={labelStyle}>{label}</label>
      <div style={{ display: 'flex', gap: '8px', marginBottom: '6px' }}>
        <input
          value={inputVal}
          onChange={e => setInputVal(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addItem())}
          placeholder={placeholder}
          style={{ ...inputStyle, flex: 1 }}
        />
        <button onClick={addItem} style={addBtnStyle}>+ Add</button>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
        {values.map((v, i) => (
          <span key={i} style={tagStyle}>
            {v}
            <button onClick={() => removeItem(i)} style={tagRemoveStyle}>×</button>
          </span>
        ))}
      </div>
    </div>
  );
};

// ── Sub-component: Section Card ─────────────────────────────
interface SectionCardProps {
  title: string;
  icon: string;
  accent: string;
  children: React.ReactNode;
}

const SectionCard: React.FC<SectionCardProps> = ({ title, icon, accent, children }) => (
  <div style={{
    background: '#0f172a', borderRadius: '12px', padding: '28px',
    border: `1px solid #1e293b`, boxShadow: '0 2px 16px rgba(0,0,0,0.3)',
    position: 'relative', overflow: 'hidden',
  }}>
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0, height: '3px',
      background: `linear-gradient(90deg, ${accent}, transparent)`,
    }} />
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
      <span style={{ fontSize: '20px' }}>{icon}</span>
      <h3 style={{ margin: 0, color: accent, fontSize: '15px', fontWeight: 700,
        textTransform: 'uppercase', letterSpacing: '1px' }}>{title}</h3>
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
      {children}
    </div>
  </div>
);

// ── Sub-component: Status Button ────────────────────────────
interface SaveButtonProps {
  status: UpdateStatus;
  onClick: () => void;
  hasChanges: boolean;
}

const SaveButton: React.FC<SaveButtonProps> = ({ status, onClick, hasChanges }) => {
  const cfg: Record<UpdateStatus, { label: string; bg: string; shadow: string }> = {
    idle:    { label: 'Save Changes to Azure AD',     bg: 'linear-gradient(135deg,#0ea5e9,#6366f1)', shadow: '0 4px 24px rgba(99,102,241,0.4)' },
    loading: { label: 'Updating Azure AD...',         bg: 'linear-gradient(135deg,#64748b,#475569)', shadow: 'none' },
    success: { label: '✓ Saved Successfully!',        bg: 'linear-gradient(135deg,#22c55e,#16a34a)', shadow: '0 4px 24px rgba(34,197,94,0.4)' },
    error:   { label: '✕ Update Failed — Retry?',    bg: 'linear-gradient(135deg,#ef4444,#dc2626)', shadow: '0 4px 24px rgba(239,68,68,0.4)' },
  };
  const { label, bg, shadow } = cfg[status];
  return (
    <button
      onClick={onClick}
      disabled={status === 'loading' || !hasChanges}
      style={{
        padding: '14px 36px', fontSize: '15px', fontWeight: 700,
        border: 'none', borderRadius: '10px', cursor: status === 'loading' || !hasChanges ? 'not-allowed' : 'pointer',
        background: !hasChanges ? '#1e293b' : bg,
        color: !hasChanges ? '#475569' : '#fff',
        boxShadow: hasChanges ? shadow : 'none',
        transition: 'all 0.3s ease', letterSpacing: '0.5px',
        opacity: status === 'loading' ? 0.7 : 1,
      }}
    >
      {status === 'loading' ? (
        <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>⟳</span>
          {label}
        </span>
      ) : label}
    </button>
  );
};

// ── Main Component ───────────────────────────────────────────
interface AzureUserEditorProps {
  userId: string;
}

export const AzureUserEditor: React.FC<AzureUserEditorProps> = ({ userId }) => {
  const { user, status, notifications, fetchUser, updateUser, clearNotification } = useAzureUser();
  const [formData, setFormData] = useState<Partial<IAzureUser>>({});
  const [hasChanges, setHasChanges] = useState(false);

  // Load user on mount
  useEffect(() => {
    fetchUser(userId);
  }, [userId, fetchUser]);

  // Populate form when user loads
  useEffect(() => {
    if (user) {
      setFormData({
        givenName: user.givenName,
        surname: user.surname,
        displayName: user.displayName,
        jobTitle: user.jobTitle,
        department: user.department,
        companyName: user.companyName,
        officeLocation: user.officeLocation,
        preferredLanguage: user.preferredLanguage,
        mobilePhone: user.mobilePhone,
        businessPhones: [...(user.businessPhones || [])],
        otherMails: [...(user.otherMails || [])],
        mailNickname: user.mailNickname,
      });
      setHasChanges(false);
    }
  }, [user]);

  const handleFieldChange = useCallback((key: keyof IAzureUser, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  }, []);

  const handleSave = useCallback(async () => {
    const payload: IUpdateUserRequest = {
      basicProfile: {
        givenName:         formData.givenName,
        surname:           formData.surname,
        displayName:       formData.displayName,
        jobTitle:          formData.jobTitle,
        department:        formData.department,
        companyName:       formData.companyName,
        officeLocation:    formData.officeLocation,
        preferredLanguage: formData.preferredLanguage,
      },
      contactProfile: {
        mobilePhone:     formData.mobilePhone,
        businessPhones:  formData.businessPhones as string[],
        otherMails:      formData.otherMails as string[],
        mailNickname:    formData.mailNickname,
      },
    };
    await updateUser(userId, payload);
    setHasChanges(false);
  }, [formData, userId, updateUser]);

  const renderField = (field: IFormField) => {
    const val = formData[field.key];

    if (field.type === 'array') {
      return (
        <div key={field.key} style={{ gridColumn: 'span 2' }}>
          <ArrayFieldEditor
            label={field.label}
            values={(val as string[]) || []}
            placeholder={field.placeholder}
            onChange={values => handleFieldChange(field.key, values)}
          />
        </div>
      );
    }

    if (field.type === 'select') {
      return (
        <div key={field.key}>
          <label style={labelStyle}>{field.label}{field.required && <span style={{ color: '#ef4444' }}> *</span>}</label>
          <select
            value={(val as string) || ''}
            onChange={e => handleFieldChange(field.key, e.target.value)}
            style={{ ...inputStyle, cursor: 'pointer' }}
          >
            <option value="">Select...</option>
            {field.options?.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        </div>
      );
    }

    return (
      <div key={field.key}>
        <label style={labelStyle}>
          {field.label}{field.required && <span style={{ color: '#ef4444' }}> *</span>}
        </label>
        <input
          type={field.type}
          value={(val as string) || ''}
          onChange={e => handleFieldChange(field.key, e.target.value)}
          placeholder={field.placeholder}
          style={inputStyle}
        />
      </div>
    );
  };

  return (
    <div style={{ minHeight: '100vh', background: '#020617', padding: '40px 20px', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <style>{`
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        input:focus, select:focus { outline: none; border-color: #6366f1 !important; box-shadow: 0 0 0 3px rgba(99,102,241,0.2); }
        input::placeholder { color: #334155; }
      `}</style>

      {/* Notification Stack */}
      <div style={{ position: 'fixed', top: '24px', right: '24px', zIndex: 9999, minWidth: '340px', maxWidth: '420px' }}>
        {notifications.map(n => (
          <NotificationToast key={n.id} notification={n} onDismiss={clearNotification} />
        ))}
      </div>

      <div style={{ maxWidth: '900px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: '36px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginBottom: '8px' }}>
            <div style={{
              width: '48px', height: '48px', borderRadius: '12px',
              background: 'linear-gradient(135deg, #0ea5e9, #6366f1)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px',
            }}>☁</div>
            <div>
              <h1 style={{ margin: 0, fontSize: '26px', fontWeight: 800, color: '#f1f5f9' }}>
                Azure AD User Profile
              </h1>
              <p style={{ margin: 0, color: '#64748b', fontSize: '13px' }}>
                Microsoft Graph API · {userId}
              </p>
            </div>
          </div>
          {user && (
            <div style={{
              marginTop: '16px', padding: '12px 16px', borderRadius: '8px',
              background: '#0f172a', border: '1px solid #1e293b',
              display: 'flex', alignItems: 'center', gap: '12px',
            }}>
              <div style={{
                width: '36px', height: '36px', borderRadius: '50%',
                background: 'linear-gradient(135deg,#6366f1,#0ea5e9)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontWeight: 700, fontSize: '14px', flexShrink: 0,
              }}>
                {(user.givenName?.[0] || '') + (user.surname?.[0] || '')}
              </div>
              <div>
                <div style={{ color: '#e2e8f0', fontWeight: 600 }}>{user.displayName}</div>
                <div style={{ color: '#64748b', fontSize: '12px' }}>{user.userPrincipalName}</div>
              </div>
              <div style={{ marginLeft: 'auto', display: 'flex', gap: '8px' }}>
                <span style={{
                  padding: '3px 10px', borderRadius: '20px', fontSize: '11px',
                  background: '#0ea5e920', color: '#0ea5e9', fontWeight: 600,
                }}>ACTIVE</span>
              </div>
            </div>
          )}
        </div>

        {status === 'loading' && !user && (
          <div style={{ textAlign: 'center', color: '#64748b', padding: '60px' }}>
            <div style={{ fontSize: '36px', marginBottom: '16px', animation: 'spin 1s linear infinite', display: 'inline-block' }}>⟳</div>
            <p>Loading user from Azure AD...</p>
          </div>
        )}

        {user && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* Basic Profile Section */}
            <SectionCard title="Basic Profile" icon="👤" accent="#6366f1">
              {BASIC_PROFILE_FIELDS.map(renderField)}
            </SectionCard>

            {/* Contact Section */}
            <SectionCard title="Contact Information" icon="📞" accent="#0ea5e9">
              {CONTACT_PROFILE_FIELDS.map(renderField)}
            </SectionCard>

            {/* Action Bar */}
            <div style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '20px 24px', background: '#0f172a', borderRadius: '12px',
              border: '1px solid #1e293b',
            }}>
              <div style={{ color: '#64748b', fontSize: '13px' }}>
                {hasChanges ? (
                  <span style={{ color: '#f59e0b' }}>● Unsaved changes</span>
                ) : (
                  <span>No pending changes</span>
                )}
              </div>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <button
                  onClick={() => fetchUser(userId)}
                  style={{
                    padding: '12px 20px', background: 'transparent', border: '1px solid #334155',
                    borderRadius: '8px', color: '#94a3b8', cursor: 'pointer', fontSize: '14px',
                  }}
                >
                  ↺ Reload
                </button>
                <SaveButton status={status} onClick={handleSave} hasChanges={hasChanges} />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ── Shared styles ────────────────────────────────────────────
const labelStyle: React.CSSProperties = {
  display: 'block', marginBottom: '6px', fontSize: '12px', fontWeight: 600,
  color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.6px',
};

const inputStyle: React.CSSProperties = {
  width: '100%', padding: '10px 14px', borderRadius: '8px', fontSize: '14px',
  background: '#0a1628', border: '1px solid #1e293b', color: '#e2e8f0',
  transition: 'border-color 0.2s, box-shadow 0.2s', boxSizing: 'border-box',
};

const addBtnStyle: React.CSSProperties = {
  padding: '10px 16px', background: '#1e293b', border: '1px solid #334155',
  borderRadius: '8px', color: '#94a3b8', cursor: 'pointer', fontSize: '13px',
  fontWeight: 600, whiteSpace: 'nowrap',
};

const tagStyle: React.CSSProperties = {
  display: 'inline-flex', alignItems: 'center', gap: '6px',
  padding: '4px 10px', background: '#1e293b', borderRadius: '20px',
  color: '#94a3b8', fontSize: '13px',
};

const tagRemoveStyle: React.CSSProperties = {
  background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer',
  fontSize: '16px', lineHeight: 1, padding: 0,
};

export default AzureUserEditor;
