// ================================================================
// NotificationStack.tsx — Reusable notification toasts
// ================================================================
import React from 'react';
import type { INotification } from '../interfaces/IAzureUser';

interface Props {
  notifications: INotification[];
  onDismiss: (id: string) => void;
}

export const NotificationStack: React.FC<Props> = ({ notifications, onDismiss }) => {
  const colorMap: Record<INotification['type'], string> = {
    success: '#22c55e', error: '#ef4444', warning: '#f59e0b', info: '#3b82f6',
  };
  const iconMap: Record<INotification['type'], string> = {
    success: '✓', error: '✕', warning: '⚠', info: 'ℹ',
  };
  return (
    <div style={{
      position: 'fixed', top: 24, right: 24, zIndex: 9999,
      minWidth: 320, maxWidth: 420, pointerEvents: 'none',
    }}>
      {notifications.map(n => (
        <div key={n.id} style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '12px 16px', borderRadius: 8, marginBottom: 8,
          background: '#1e293b', borderLeft: `4px solid ${colorMap[n.type]}`,
          boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
          animation: 'slideIn 0.3s ease', pointerEvents: 'all',
        }}>
          <span style={{ color: colorMap[n.type], fontWeight: 700, fontSize: 16 }}>
            {iconMap[n.type]}
          </span>
          <span style={{ color: '#e2e8f0', flex: 1, fontSize: 14 }}>{n.message}</span>
          <button
            onClick={() => onDismiss(n.id)}
            style={{ background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', fontSize: 18 }}
          >×</button>
        </div>
      ))}
    </div>
  );
};
