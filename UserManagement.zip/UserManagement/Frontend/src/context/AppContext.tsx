// ================================================================
// AppContext.tsx — Global navigation state (Search ↔ Detail)
// ================================================================
import React, { createContext, useContext, useState, useCallback } from 'react';
import type { IAzureUser, AppView } from '../interfaces/IAzureUser';

interface IAppContextValue {
  currentView: AppView;
  selectedUser: IAzureUser | null;
  navigateToDetail: (user: IAzureUser) => void;
  navigateToSearch: () => void;
}

const AppContext = createContext<IAppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<AppView>('search');
  const [selectedUser, setSelectedUser] = useState<IAzureUser | null>(null);

  const navigateToDetail = useCallback((user: IAzureUser) => {
    setSelectedUser(user);
    setCurrentView('detail');
  }, []);

  const navigateToSearch = useCallback(() => {
    setCurrentView('search');
  }, []);

  return (
    <AppContext.Provider value={{ currentView, selectedUser, navigateToDetail, navigateToSearch }}>
      {children}
    </AppContext.Provider>
  );
};

export function useAppContext(): IAppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
}
