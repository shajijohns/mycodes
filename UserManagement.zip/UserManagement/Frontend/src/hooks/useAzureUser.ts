// useAzureUser.ts - Custom React Hook
import { useState, useCallback } from 'react';
import type { IAzureUser, IUpdateUserRequest, IApiResponse, UpdateStatus, INotification } from '../interfaces/IAzureUser';
import { azureGraphService } from '../services/AzureGraphService';

interface UseAzureUserReturn {
  user: IAzureUser | null;
  status: UpdateStatus;
  notifications: INotification[];
  fetchUser: (userId: string) => Promise<void>;
  updateUser: (userId: string, payload: IUpdateUserRequest) => Promise<IApiResponse<IAzureUser>>;
  clearNotification: (id: string) => void;
}

const uid = (): string => Math.random().toString(36).slice(2, 9);

export function useAzureUser(): UseAzureUserReturn {
  const [user, setUser] = useState<IAzureUser | null>(null);
  const [status, setStatus] = useState<UpdateStatus>('idle');
  const [notifications, setNotifications] = useState<INotification[]>([]);

  const push = useCallback((type: INotification['type'], message: string) => {
    const note: INotification = { id: uid(), type, message, timestamp: Date.now() };
    setNotifications(prev => [note, ...prev].slice(0, 5));
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== note.id)), 5500);
  }, []);

  const clearNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const fetchUser = useCallback(async (userId: string): Promise<void> => {
    setStatus('loading');
    const result = await azureGraphService.getUser(userId);
    if (result.success && result.data) {
      setUser(result.data);
      setStatus('idle');
      push('info', 'User profile loaded.');
    } else {
      setStatus('error');
      push('error', result.message || 'Failed to load user.');
    }
  }, [push]);

  const updateUser = useCallback(async (
    userId: string,
    payload: IUpdateUserRequest
  ): Promise<IApiResponse<IAzureUser>> => {
    setStatus('loading');
    const result = await azureGraphService.updateUser(userId, payload);
    if (result.success && result.data) {
      setUser(result.data);
      setStatus('success');
      push('success', 'Profile updated in Azure AD!');
    } else {
      setStatus('error');
      push('error', result.errors?.join(', ') || result.message || 'Update failed');
    }
    setTimeout(() => setStatus('idle'), 2500);
    return result;
  }, [push]);

  return { user, status, notifications, fetchUser, updateUser, clearNotification };
}
