// ================================================================
// useUserSearch.ts — Hook for user search + grid state
// ================================================================
import { useState, useCallback } from 'react';
import type {
  IAzureUser,
  IUserSearchQuery,
  IUserSearchResult,
  ISortState,
  INotification,
} from '../interfaces/IAzureUser';
import { azureGraphService } from '../services/AzureGraphService';

const uid = (): string => Math.random().toString(36).slice(2, 9);

interface UseUserSearchReturn {
  results: IAzureUser[];
  totalCount: number;
  isLoading: boolean;
  hasSearched: boolean;
  query: IUserSearchQuery;
  sortState: ISortState;
  notifications: INotification[];
  setQuery: (q: Partial<IUserSearchQuery>) => void;
  executeSearch: (overrideQuery?: Partial<IUserSearchQuery>) => Promise<void>;
  handleSort: (column: keyof IAzureUser) => void;
  sortedResults: IAzureUser[];
  clearNotification: (id: string) => void;
  clearResults: () => void;
}

const DEFAULT_QUERY: IUserSearchQuery = {
  searchTerm: '',
  searchBy: 'displayName',
  pageSize: 20,
  pageNumber: 1,
};

export function useUserSearch(): UseUserSearchReturn {
  const [results, setResults] = useState<IAzureUser[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [query, setQueryState] = useState<IUserSearchQuery>(DEFAULT_QUERY);
  const [sortState, setSortState] = useState<ISortState>({ column: null, direction: 'asc' });
  const [notifications, setNotifications] = useState<INotification[]>([]);

  const push = useCallback((type: INotification['type'], message: string) => {
    const note: INotification = { id: uid(), type, message, timestamp: Date.now() };
    setNotifications(prev => [note, ...prev].slice(0, 4));
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== note.id)), 5000);
  }, []);

  const clearNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const setQuery = useCallback((partial: Partial<IUserSearchQuery>) => {
    setQueryState(prev => ({ ...prev, ...partial }));
  }, []);

  const executeSearch = useCallback(async (overrideQuery?: Partial<IUserSearchQuery>) => {
    const finalQuery = overrideQuery ? { ...query, ...overrideQuery } : query;
    if (!finalQuery.searchTerm.trim()) {
      push('warning', 'Please enter a search term.');
      return;
    }
    setIsLoading(true);
    setHasSearched(true);
    const result = await azureGraphService.searchUsers(finalQuery);
    setIsLoading(false);
    if (result.success && result.data) {
      const data = result.data as IUserSearchResult;
      setResults(data.users);
      setTotalCount(data.totalCount);
      if (data.users.length === 0) {
        push('info', `No users found matching "${finalQuery.searchTerm}".`);
      } else {
        push('success', `Found ${data.totalCount} user(s).`);
      }
    } else {
      push('error', result.message || 'Search failed.');
      setResults([]);
    }
  }, [query, push]);

  const handleSort = useCallback((column: keyof IAzureUser) => {
    setSortState(prev => ({
      column,
      direction: prev.column === column && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  }, []);

  const sortedResults = [...results].sort((a, b) => {
    if (!sortState.column) return 0;
    const aVal = String(a[sortState.column] ?? '').toLowerCase();
    const bVal = String(b[sortState.column] ?? '').toLowerCase();
    const cmp = aVal.localeCompare(bVal);
    return sortState.direction === 'asc' ? cmp : -cmp;
  });

  const clearResults = useCallback(() => {
    setResults([]);
    setTotalCount(0);
    setHasSearched(false);
    setQueryState(DEFAULT_QUERY);
  }, []);

  return {
    results,
    totalCount,
    isLoading,
    hasSearched,
    query,
    sortState,
    notifications,
    setQuery,
    executeSearch,
    handleSort,
    sortedResults,
    clearNotification,
    clearResults,
  };
}
