import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
    plugins: [react()],
    // root must point to the folder that contains index.html
    root: __dirname,
    server: {
        port: 3000,
        proxy: {
            '/api': {
                target: 'https://localhost:59297',
                changeOrigin: true,
                secure: false,
            },
        },
    },
    build: {
        outDir: path.resolve(__dirname, '../dist'),
        emptyOutDir: true,
    },
});
