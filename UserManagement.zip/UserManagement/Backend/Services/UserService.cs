// UserService.cs — Microsoft Graph API Implementation
using Microsoft.Graph;
using Microsoft.Graph.Models;
using Microsoft.Graph.Models.ODataErrors;
using AzureGraphEditor.Backend.DTOs;
using AzureGraphEditor.Backend.Interfaces;

namespace AzureGraphEditor.Backend.Services
{
    public sealed class UserService : IUserService
    {
        private readonly GraphServiceClient   _graphClient;
        private readonly ILogger<UserService> _logger;

        private static readonly string[] SelectFields =
        {
            "id", "userPrincipalName", "mail", "givenName", "surname", "displayName",
            "jobTitle", "department", "companyName", "officeLocation", "preferredLanguage",
            "mobilePhone", "businessPhones", "otherMails", "mailNickname"
        };

        public UserService(GraphServiceClient graphClient, ILogger<UserService> logger)
        {
            _graphClient = graphClient;
            _logger      = logger;
        }

        // ── GET single user ───────────────────────────────────
        public async Task<ServiceResult<UserProfileDto>> GetUserAsync(
            string userId, CancellationToken ct = default)
        {
            try
            {
                var user = await _graphClient.Users[userId]
                    .GetAsync(req => req.QueryParameters.Select = SelectFields, ct);

                return user is null
                    ? ServiceResult<UserProfileDto>.NotFound()
                    : ServiceResult<UserProfileDto>.Ok(MapToDto(user));
            }
            catch (ODataError ex) when (ex.ResponseStatusCode == 404)
            {
                _logger.LogWarning("User {UserId} not found.", userId);
                return ServiceResult<UserProfileDto>.NotFound($"User '{userId}' not found.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetUser failed for {UserId}", userId);
                return ServiceResult<UserProfileDto>.Fail("Failed to retrieve user.", 500);
            }
        }

        // ── SEARCH users via Graph $filter ────────────────────
        public async Task<ServiceResult<UserSearchResultDto>> SearchUsersAsync(
            UserSearchQueryDto query, CancellationToken ct = default)
        {
            try
            {
                var filterField = query.SearchBy switch
                {
                    "mail"              => "mail",
                    "userPrincipalName" => "userPrincipalName",
                    "department"        => "department",
                    "jobTitle"          => "jobTitle",
                    _                   => "displayName",
                };

                var escaped = query.SearchTerm.Replace("'", "''");
                var filter  = $"startsWith({filterField},'{escaped}')";

                // Note: Graph SDK v5 UsersRequestBuilder does not expose $skip on QueryParameters.
                // Pagination is handled by walking @odata.nextLink pages up to the requested page number.
                var response = await _graphClient.Users.GetAsync(req =>
                {
                    req.QueryParameters.Select  = SelectFields;
                    req.QueryParameters.Filter  = filter;
                    req.QueryParameters.Top     = query.PageSize;
                    req.QueryParameters.Orderby = new[] { "displayName" };
                    req.QueryParameters.Count   = true;
                    req.Headers.Add("ConsistencyLevel", "eventual");
                }, ct);

                // Walk nextLink pages to reach the requested page number
                for (int page = 1; page < query.PageNumber && response?.OdataNextLink != null; page++)
                {
                    response = await _graphClient.Users
                        .WithUrl(response.OdataNextLink)
                        .GetAsync(cancellationToken: ct);
                }

                var users = response?.Value ?? new List<User>();
                var dtos  = users.Select(MapToDto).ToList();
                var total = (int)(response?.OdataCount ?? dtos.Count);

                return ServiceResult<UserSearchResultDto>.Ok(new UserSearchResultDto
                {
                    Users       = dtos,
                    TotalCount  = total,
                    PageNumber  = query.PageNumber,
                    PageSize    = query.PageSize,
                    HasNextPage = dtos.Count == query.PageSize,
                });
            }
            catch (ODataError ex)
            {
                _logger.LogError(ex, "SearchUsers Graph error for term={Term}", query.SearchTerm);
                return ServiceResult<UserSearchResultDto>.Fail(
                    ex.Error?.Message ?? "Graph search failed.", ex.ResponseStatusCode);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SearchUsers failed for term={Term}", query.SearchTerm);
                return ServiceResult<UserSearchResultDto>.Fail("Search request failed.", 500);
            }
        }

        // ── PATCH both sections ───────────────────────────────
        public async Task<ServiceResult<UserProfileDto>> UpdateUserAsync(
            string userId, UpdateUserRequest request, CancellationToken ct = default)
        {
            try
            {
                var patch = new User();
                if (request.BasicProfile   is not null) ApplyBasicProfile(patch, request.BasicProfile);
                if (request.ContactProfile is not null) ApplyContactProfile(patch, request.ContactProfile);
                await _graphClient.Users[userId].PatchAsync(patch, cancellationToken: ct);
                return await GetUserAsync(userId, ct);
            }
            catch (ODataError ex) when (ex.ResponseStatusCode == 403)
            {
                return ServiceResult<UserProfileDto>.Fail(
                    "Insufficient Graph permissions — ensure User.ReadWrite.All is consented.", 403);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateUser failed for {UserId}", userId);
                return ServiceResult<UserProfileDto>.Fail("Update failed.", 500);
            }
        }

        public async Task<ServiceResult<UserProfileDto>> UpdateBasicProfileAsync(
            string userId, BasicProfileDto dto, CancellationToken ct = default)
        {
            var patch = new User();
            ApplyBasicProfile(patch, dto);
            return await PatchAndFetch(userId, patch, ct);
        }

        public async Task<ServiceResult<UserProfileDto>> UpdateContactProfileAsync(
            string userId, ContactProfileDto dto, CancellationToken ct = default)
        {
            var patch = new User();
            ApplyContactProfile(patch, dto);
            return await PatchAndFetch(userId, patch, ct);
        }

        // ── Helpers ───────────────────────────────────────────
        private async Task<ServiceResult<UserProfileDto>> PatchAndFetch(
            string userId, User patch, CancellationToken ct)
        {
            try
            {
                await _graphClient.Users[userId].PatchAsync(patch, cancellationToken: ct);
                return await GetUserAsync(userId, ct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "PatchAndFetch failed for {UserId}", userId);
                return ServiceResult<UserProfileDto>.Fail("Patch failed.", 500);
            }
        }

        private static void ApplyBasicProfile(User u, BasicProfileDto d)
        {
            if (d.GivenName         is not null) u.GivenName         = d.GivenName;
            if (d.Surname           is not null) u.Surname           = d.Surname;
            if (d.DisplayName       is not null) u.DisplayName       = d.DisplayName;
            if (d.JobTitle          is not null) u.JobTitle          = d.JobTitle;
            if (d.Department        is not null) u.Department        = d.Department;
            if (d.CompanyName       is not null) u.CompanyName       = d.CompanyName;
            if (d.OfficeLocation    is not null) u.OfficeLocation    = d.OfficeLocation;
            if (d.PreferredLanguage is not null) u.PreferredLanguage = d.PreferredLanguage;
        }

        private static void ApplyContactProfile(User u, ContactProfileDto d)
        {
            if (d.MobilePhone    is not null) u.MobilePhone    = d.MobilePhone;
            if (d.BusinessPhones is not null) u.BusinessPhones = d.BusinessPhones;
            if (d.OtherMails     is not null) u.OtherMails     = d.OtherMails;
            if (d.MailNickname   is not null) u.MailNickname   = d.MailNickname;
        }

        private static UserProfileDto MapToDto(User u) => new UserProfileDto
        {
            Id                = u.Id                ?? string.Empty,
            UserPrincipalName = u.UserPrincipalName ?? string.Empty,
            Mail              = u.Mail              ?? string.Empty,
            GivenName         = u.GivenName         ?? string.Empty,
            Surname           = u.Surname           ?? string.Empty,
            DisplayName       = u.DisplayName       ?? string.Empty,
            JobTitle          = u.JobTitle          ?? string.Empty,
            Department        = u.Department        ?? string.Empty,
            CompanyName       = u.CompanyName       ?? string.Empty,
            OfficeLocation    = u.OfficeLocation    ?? string.Empty,
            PreferredLanguage = u.PreferredLanguage ?? string.Empty,
            MobilePhone       = u.MobilePhone,
            BusinessPhones    = u.BusinessPhones?.ToList() ?? new List<string>(),
            OtherMails        = u.OtherMails?.ToList()     ?? new List<string>(),
            MailNickname      = u.MailNickname ?? string.Empty,
        };
    }
}
