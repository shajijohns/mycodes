// Program.cs — .NET 9 ASP.NET Core Web API entry point
using Azure.Identity;
using Microsoft.Graph;
using AzureGraphEditor.Backend.Interfaces;
using AzureGraphEditor.Backend.Services;

var builder = WebApplication.CreateBuilder(args);

// ── Microsoft Graph client ────────────────────────────────────
builder.Services.AddSingleton<GraphServiceClient>(sp =>
{
    var cfg          = builder.Configuration.GetSection("AzureAd");
    var tenantId     = cfg["TenantId"]     ?? throw new InvalidOperationException("AzureAd:TenantId missing.");
    var clientId     = cfg["ClientId"]     ?? throw new InvalidOperationException("AzureAd:ClientId missing.");
    var clientSecret = cfg["ClientSecret"] ?? throw new InvalidOperationException("AzureAd:ClientSecret missing.");

    var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
    return new GraphServiceClient(credential, new[] { "https://graph.microsoft.com/.default" });
});

// ── Dependency injection ──────────────────────────────────────
builder.Services.AddScoped<IUserService, UserService>();

// ── MVC + Swagger ─────────────────────────────────────────────
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title       = "Azure Graph Editor API",
        Version     = "v1",
        Description = "Microsoft Graph user management — Search, View, Edit"
    });
});

// ── CORS for React dev server (port 3000) ─────────────────────
builder.Services.AddCors(opt =>
    opt.AddPolicy("DevCors", p =>
        p.WithOrigins("http://localhost:3000", "https://localhost:3000")
         .AllowAnyHeader()
         .AllowAnyMethod()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Azure Graph Editor API v1");
        c.RoutePrefix = "swagger";
    });
    // Redirect root to swagger
    app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();
}

app.UseCors("DevCors");
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
