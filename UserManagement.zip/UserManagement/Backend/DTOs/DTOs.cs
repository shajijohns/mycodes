// DTOs.cs - Data Transfer Objects for Azure Graph User API
using System.ComponentModel.DataAnnotations;

namespace AzureGraphEditor.Backend.DTOs
{
    public sealed class UserProfileDto
    {
        public string Id                { get; set; } = string.Empty;
        public string UserPrincipalName { get; set; } = string.Empty;
        public string Mail              { get; set; } = string.Empty;
        public string GivenName         { get; set; } = string.Empty;
        public string Surname           { get; set; } = string.Empty;
        public string DisplayName       { get; set; } = string.Empty;
        public string JobTitle          { get; set; } = string.Empty;
        public string Department        { get; set; } = string.Empty;
        public string CompanyName       { get; set; } = string.Empty;
        public string OfficeLocation    { get; set; } = string.Empty;
        public string PreferredLanguage { get; set; } = string.Empty;
        public string? MobilePhone      { get; set; }
        public List<string> BusinessPhones { get; set; } = new();
        public List<string> OtherMails    { get; set; } = new();
        public string MailNickname        { get; set; } = string.Empty;
    }

    public sealed class BasicProfileDto
    {
        [StringLength(64)]  public string? GivenName         { get; set; }
        [StringLength(64)]  public string? Surname           { get; set; }
        [StringLength(128)] public string? DisplayName       { get; set; }
        [StringLength(128)] public string? JobTitle          { get; set; }
        [StringLength(128)] public string? Department        { get; set; }
        [StringLength(128)] public string? CompanyName       { get; set; }
        [StringLength(128)] public string? OfficeLocation    { get; set; }
        [StringLength(10)]  public string? PreferredLanguage { get; set; }
    }

    public sealed class ContactProfileDto
    {
        [Phone][StringLength(32)] public string?       MobilePhone    { get; set; }
        public List<string>?      BusinessPhones       { get; set; }
        public List<string>?      OtherMails           { get; set; }
        [StringLength(64)]        public string?       MailNickname   { get; set; }
    }

    public sealed class UpdateUserRequest
    {
        public BasicProfileDto?   BasicProfile   { get; set; }
        public ContactProfileDto? ContactProfile { get; set; }
    }

    public sealed class ApiResponse<T>
    {
        public bool                Success    { get; set; }
        public T?                  Data       { get; set; }
        public string              Message    { get; set; } = string.Empty;
        public IEnumerable<string> Errors     { get; set; } = Enumerable.Empty<string>();
        public int                 StatusCode { get; set; }

        public static ApiResponse<T> Ok(T data, string message = "Success") =>
            new() { Success = true, Data = data, Message = message, StatusCode = 200 };

        public static ApiResponse<T> Fail(string message, int code = 400, IEnumerable<string>? errors = null) =>
            new() { Success = false, Message = message, StatusCode = code,
                    Errors = errors ?? Enumerable.Empty<string>() };
    }
}
