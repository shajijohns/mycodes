// SearchDTOs.cs — DTOs for user search/list operations
namespace AzureGraphEditor.Backend.DTOs
{
    /// <summary>Query parameters for user search via MS Graph $filter</summary>
    public sealed class UserSearchQueryDto
    {
        public string SearchTerm  { get; set; } = string.Empty;
        public string SearchBy    { get; set; } = "displayName";
        public int    PageSize    { get; set; } = 20;
        public int    PageNumber  { get; set; } = 1;
    }

    /// <summary>Paginated search result envelope</summary>
    public sealed class UserSearchResultDto
    {
        public List<UserProfileDto> Users       { get; set; } = new List<UserProfileDto>();
        public int                  TotalCount  { get; set; }
        public int                  PageNumber  { get; set; }
        public int                  PageSize    { get; set; }
        public bool                 HasNextPage { get; set; }
    }
}
