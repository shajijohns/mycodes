// IUserService.cs — Service contract for Azure AD user operations
using AzureGraphEditor.Backend.DTOs;

namespace AzureGraphEditor.Backend.Interfaces
{
    public interface IUserService
    {
        Task<ServiceResult<UserProfileDto>>      GetUserAsync(string userId, CancellationToken ct = default);
        Task<ServiceResult<UserSearchResultDto>> SearchUsersAsync(UserSearchQueryDto query, CancellationToken ct = default);
        Task<ServiceResult<UserProfileDto>>      UpdateUserAsync(string userId, UpdateUserRequest request, CancellationToken ct = default);
        Task<ServiceResult<UserProfileDto>>      UpdateBasicProfileAsync(string userId, BasicProfileDto dto, CancellationToken ct = default);
        Task<ServiceResult<UserProfileDto>>      UpdateContactProfileAsync(string userId, ContactProfileDto dto, CancellationToken ct = default);
    }

    public sealed class ServiceResult<T>
    {
        public bool                Success    { get; private init; }
        public T?                  Data       { get; private init; }
        public string              Message    { get; private init; } = string.Empty;
        public IEnumerable<string> Errors     { get; private init; } = Enumerable.Empty<string>();
        public int                 StatusCode { get; private init; }

        public static ServiceResult<T> Ok(T data, string message = "Success") =>
            new ServiceResult<T> { Success = true, Data = data, Message = message, StatusCode = 200 };

        public static ServiceResult<T> Fail(string message, int statusCode = 400, IEnumerable<string>? errors = null) =>
            new ServiceResult<T> { Success = false, Message = message, StatusCode = statusCode,
                                   Errors = errors ?? Enumerable.Empty<string>() };

        public static ServiceResult<T> NotFound(string message = "Resource not found") =>
            new ServiceResult<T> { Success = false, Message = message, StatusCode = 404 };
    }
}
