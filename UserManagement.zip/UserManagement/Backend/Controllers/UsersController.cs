// UsersController.cs — REST API for Azure AD User Management
using Microsoft.AspNetCore.Mvc;
using AzureGraphEditor.Backend.DTOs;
using AzureGraphEditor.Backend.Interfaces;

namespace AzureGraphEditor.Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public sealed class UsersController : ControllerBase
    {
        private readonly IUserService             _userService;
        private readonly ILogger<UsersController> _logger;

        public UsersController(IUserService userService, ILogger<UsersController> logger)
        {
            _userService = userService;
            _logger      = logger;
        }

        // ── GET /api/users/search ─────────────────────────────
        // NOTE: "search" literal route MUST appear before "{userId}" so ASP.NET
        // does not treat the word "search" as a userId value.
        [HttpGet("search")]
        [ProducesResponseType(typeof(ApiResponse<UserSearchResultDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<UserSearchResultDto>), 400)]
        public async Task<IActionResult> SearchUsers(
            [FromQuery] string searchTerm,
            [FromQuery] string searchBy   = "displayName",
            [FromQuery] int    pageSize   = 20,
            [FromQuery] int    pageNumber = 1,
            CancellationToken  ct         = default)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return BadRequest(ApiResponse<UserSearchResultDto>.Fail("searchTerm is required."));

            if (pageSize is < 1 or > 999)
                return BadRequest(ApiResponse<UserSearchResultDto>.Fail("pageSize must be 1-999."));

            _logger.LogInformation("SearchUsers: term={Term} by={By} page={Page} size={Size}",
                searchTerm, searchBy, pageNumber, pageSize);

            var query = new UserSearchQueryDto
            {
                SearchTerm  = searchTerm.Trim(),
                SearchBy    = searchBy,
                PageSize    = pageSize,
                PageNumber  = pageNumber,
            };

            var result = await _userService.SearchUsersAsync(query, ct);

            if (!result.Success)
                return StatusCode(result.StatusCode,
                    ApiResponse<UserSearchResultDto>.Fail(result.Message, result.StatusCode, result.Errors));

            return Ok(ApiResponse<UserSearchResultDto>.Ok(result.Data!,
                $"Found {result.Data!.TotalCount} user(s)."));
        }

        // ── GET /api/users/{userId} ───────────────────────────
        [HttpGet("{userId}")]
        [ProducesResponseType(typeof(ApiResponse<UserProfileDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<UserProfileDto>), 404)]
        public async Task<IActionResult> GetUser(string userId, CancellationToken ct)
        {
            _logger.LogInformation("GetUser: {UserId}", userId);
            var result = await _userService.GetUserAsync(userId, ct);
            if (!result.Success)
                return StatusCode(result.StatusCode,
                    ApiResponse<UserProfileDto>.Fail(result.Message, result.StatusCode, result.Errors));
            return Ok(ApiResponse<UserProfileDto>.Ok(result.Data!));
        }

        // ── PATCH /api/users/{userId} ─────────────────────────
        [HttpPatch("{userId}")]
        [ProducesResponseType(typeof(ApiResponse<UserProfileDto>), 200)]
        public async Task<IActionResult> UpdateUser(
            string userId, [FromBody] UpdateUserRequest request, CancellationToken ct)
        {
            if (request.BasicProfile is null && request.ContactProfile is null)
                return BadRequest(ApiResponse<UserProfileDto>.Fail(
                    "Request must include at least one section."));

            var result = await _userService.UpdateUserAsync(userId, request, ct);
            if (!result.Success)
                return StatusCode(result.StatusCode,
                    ApiResponse<UserProfileDto>.Fail(result.Message, result.StatusCode, result.Errors));
            return Ok(ApiResponse<UserProfileDto>.Ok(result.Data!, "User updated successfully."));
        }

        // ── PATCH /api/users/{userId}/basic-profile ───────────
        [HttpPatch("{userId}/basic-profile")]
        [ProducesResponseType(typeof(ApiResponse<UserProfileDto>), 200)]
        public async Task<IActionResult> UpdateBasicProfile(
            string userId, [FromBody] BasicProfileDto dto, CancellationToken ct)
        {
            var result = await _userService.UpdateBasicProfileAsync(userId, dto, ct);
            if (!result.Success)
                return StatusCode(result.StatusCode,
                    ApiResponse<UserProfileDto>.Fail(result.Message, result.StatusCode, result.Errors));
            return Ok(ApiResponse<UserProfileDto>.Ok(result.Data!, "Basic profile updated."));
        }

        // ── PATCH /api/users/{userId}/contact-profile ─────────
        [HttpPatch("{userId}/contact-profile")]
        [ProducesResponseType(typeof(ApiResponse<UserProfileDto>), 200)]
        public async Task<IActionResult> UpdateContactProfile(
            string userId, [FromBody] ContactProfileDto dto, CancellationToken ct)
        {
            var result = await _userService.UpdateContactProfileAsync(userId, dto, ct);
            if (!result.Success)
                return StatusCode(result.StatusCode,
                    ApiResponse<UserProfileDto>.Fail(result.Message, result.StatusCode, result.Errors));
            return Ok(ApiResponse<UserProfileDto>.Ok(result.Data!, "Contact profile updated."));
        }
    }
}
