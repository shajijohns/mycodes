import type { Configuration, RedirectRequest } from "@azure/msal-browser";

export const msalConfig: Configuration = {
    auth: {
        clientId:              import.meta.env.VITE_CLIENT_ID,
        authority:             import.meta.env.VITE_AUTHORITY,
        knownAuthorities:      [import.meta.env.VITE_KNOWN_AUTHORITY],
        redirectUri:           import.meta.env.VITE_REDIRECT_URI,
        postLogoutRedirectUri: import.meta.env.VITE_REDIRECT_URI,
    },
    cache: {
        cacheLocation: "localStorage",
    },
};

// B2C scopes — openid and profile only (no User.Read for B2C)
export const loginRequest: RedirectRequest = {
    scopes: ["openid", "profile"],
};

export const graphConfig = {
    baseUrl:  "https://graph.microsoft.com/v1.0",
    tenantId: import.meta.env.VITE_TENANT_ID,
};
