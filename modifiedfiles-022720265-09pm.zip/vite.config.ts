import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
    plugins: [react()],
    server: {
        port: 5173,
        https: true,                    // ← Bill recommends HTTPS
        proxy: {
            "/api": {
                target:       "https://localhost:7062",
                changeOrigin: true,
                secure:       false,    // allow self-signed cert in dev
            },
        },
    },
});
